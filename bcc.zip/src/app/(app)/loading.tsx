import { Loader2 } from 'lucide-react'
export default function AppLoading() {
  return <div className="flex items-center justify-center py-32"><Loader2 className="h-8 w-8 animate-spin text-muted-foreground" /></div>
}
